# Ladder pilot artifacts

Generated source, tests, dependency locks, proposals, implementation notes, and
grader output for all twelve planned builds. Case and guidance bytes are frozen
copies. See summary.json and protocol.md for measurements and limits.

No authentication files, request headers, CLI initial-context bodies, or raw
generation transcripts are included. Temporary workspace paths in documentation
and grader logs are replaced with logical bundle paths. Generated source bytes
are unchanged and checked against summary.json source hashes.

To recheck a completed sample, cd to MODEL/RUN/workspace, install its locked
dependencies with lifecycle scripts disabled, typecheck it, run its src tests,
then copy MODEL/inputs/acceptance into the sample and run bun test ./acceptance.
The repository's ladder-analysis.ts can recompute summary.json from the extracted
mini and 5.5 folders. The repository's probe.ts can rerun the five exploratory
boundary probes against those folders. Sources are benchmark model outputs;
they include documented failures and are not production library code.

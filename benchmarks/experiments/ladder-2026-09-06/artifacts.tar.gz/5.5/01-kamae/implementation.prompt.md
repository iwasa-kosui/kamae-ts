Work only in this workspace. Read PRD.md and API.md.
Use only the supplied workspace materials; do not inspect parent directories,
user-global rules, other projects, other runs, or external websites.
Make reasonable assumptions and record them; this is an unattended benchmark.
Do not commit, publish, or delegate. Make your own design and library choices;
you are authorized to choose without asking for preferences or approval.
Do not modify PRD.md, API.md, tsconfig.json, or supplied skill files.
Write application code and tests under src/.
Use the $kamae skill at .agents/skills/kamae/SKILL.md and its relevant guides. Only the supplied .agents/rules defaults apply; do not load user-global rules.
Implement the supplied DESIGN.md and every requirement in PRD.md.
Do not edit DESIGN.md; it is the frozen proposal from the design phase.
Export the required adapter from src/index.ts. Write meaningful tests in src/.
The selected dependencies have been installed. Do not edit package.json or bun.lock.
Run bun run typecheck and bun test ./src, and fix failures within this session.
Write IMPLEMENTATION.md mapping the design to actual files, explaining deviations,
listing validation performed, and documenting remaining limitations.

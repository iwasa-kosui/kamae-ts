Work only in this workspace. Read PRD.md and API.md.
Use only the supplied workspace materials; do not inspect parent directories,
user-global rules, other projects, other runs, or external websites.
Make reasonable assumptions and record them; this is an unattended benchmark.
Do not commit, publish, or delegate. Make your own design and library choices;
you are authorized to choose without asking for preferences or approval.
Do not modify PRD.md, API.md, tsconfig.json, or supplied skill files.
Write application code and tests under src/.
Use the $kamae skill at .agents/skills/kamae/SKILL.md and its relevant guides. Only the supplied .agents/rules defaults apply; do not load user-global rules.
First produce DESIGN.md; do not implement yet.
Describe the design you propose for this product and explain your choices.
You may edit only the dependencies field of package.json to select runtime
packages (exact registry versions). The runner installs them after this phase;
do not install packages yourself. No additional packages is also a valid choice.
